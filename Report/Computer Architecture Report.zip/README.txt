Repository: https://github.com/hoang-himself/hcmut-report
Issues: https://github.com/hoang-himself/hcmut-report/issues
Commit: 350906b86be7adae1c953217029cbe12ad4f6ac5 refactor: update `listings` styles
